#!/usr/bin/env python3
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent
manifest = root / "KIT_SHA256SUMS.txt"
failures = []
checked = 0
for line in manifest.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    expected, relative = line.split("  ", 1)
    path = root / relative
    if not path.is_file():
        failures.append(f"missing:{relative}")
        continue
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    checked += 1
    if actual != expected:
        failures.append(f"mismatch:{relative}")
print(f"checked={checked}")
for failure in failures:
    print(failure)
raise SystemExit(1 if failures else 0)
