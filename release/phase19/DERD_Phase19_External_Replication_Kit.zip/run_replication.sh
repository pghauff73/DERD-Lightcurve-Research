#!/bin/sh
set -eu
python verify_kit.py
python -m derd.phase19_external_runner --kit . --output submission.json --operator-id "${OPERATOR_ID:?}" --organization "${ORGANIZATION:?}" --wheel software/derd_lightcurve-1.9.0-py3-none-any.whl
