# DERD Phase-19 blind external replication kit

This kit tests computational portability of the frozen DERD harmonic pipeline.
It contains four opaque synthetic photometry controls and three blinded,
derived observational harmonic-exchange controls. It contains no private
answer key and no complete third-party raw stellar photometry.

## Execute

1. Create an isolated Python 3.10+ environment.
2. Install the exact DERD wheel from `software/` and compatible NumPy/SciPy.
3. Verify the kit:

   `python verify_kit.py`

4. Run every task:

   `python -m derd.phase19_external_runner --kit . --output submission.json --operator-id YOUR_ID --organization YOUR_ORGANIZATION --wheel software/derd_lightcurve-1.9.0-py3-none-any.whl`

5. Freeze and transmit the SHA-256 of `submission.json` before the private
   answer key is disclosed.

## Independence declaration

A numeric match is necessary but not sufficient for an external-replication
edge. The operator must be outside the implementation team, must not receive
the private evaluator before submission, and must execute the commands in an
environment they control.

## Scope

This kit tests software execution, signed harmonic transport, recurrence
screening, uncertainty propagation, and deterministic direct fitting. It does
not establish a unique stellar mechanism, a transparent shell, or a mass
estimate.
